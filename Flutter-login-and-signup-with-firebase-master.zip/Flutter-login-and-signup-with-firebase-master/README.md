# flutter_firebase_app

A new Flutter project.

#### Firebase link : https://console.firebase.google.com/u/0/project/fir-getx-app-6c993/authentication/users
<div>
      <img style="width: 250px;" src="https://user-images.githubusercontent.com/68488154/145664385-9b3746fc-0519-4cef-bc15-9b2b4c68efe9.jpg" alt="">
      <img style="width: 250px;" src="https://user-images.githubusercontent.com/68488154/145664387-6a58101d-d132-4e92-94be-164a2d368c17.jpg" alt="">
      <img style="width: 250px;" src="https://user-images.githubusercontent.com/68488154/145664388-ff6f5582-88a1-4f94-bfd7-535d472f668e.jpg" alt="">
</div>

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
