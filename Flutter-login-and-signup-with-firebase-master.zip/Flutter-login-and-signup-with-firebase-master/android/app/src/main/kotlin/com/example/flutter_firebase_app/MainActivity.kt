package com.example.flutter_firebase_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
